package in.anil.springscala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringscalaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringscalaApplication.class, args);
	}
}
